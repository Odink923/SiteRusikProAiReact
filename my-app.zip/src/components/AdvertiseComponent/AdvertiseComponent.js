import React from 'react';
import ShadowCard from './UI/ShadowCard';
import styles from './AdvertiseComponent.module.css';

const AdvertiseComponent = () => {
  return (
    <div className={styles.component}>
    <div className={styles.textUnder}>
      Заходи та конференції за участі Руслана
    </div>

    <div className={styles.shadowcards}>
    <ShadowCard
        src="/images/baner1.jpg"
        alt="Руки з кольоровим пігментом"
        caption="7 червня: Конференція Триєдність Успіху"
      />
         <ShadowCard
        src="/images/baner2.png"
        alt="Руки з кольоровим пігментом"
        caption="7 червня: Конференція Триєдність Успіху"
      />
         <ShadowCard
        src="/images/baner3.png"
        alt="Руки з кольоровим пігментом"
        caption="7 червня: Конференція Триєдність Успіху"
      />
      </div>
    </div>
  );
};

export default AdvertiseComponent;