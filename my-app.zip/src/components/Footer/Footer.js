import React from 'react';

const Footer = () => {
  return (
    <div style={{marginTop:"62px", display:'flex', justifyContent:'flex-end', alignItems:'flex-end', marginBottom:"144px"}}>
     
     <div>
<img src="/images/logoTelegram.png"  alt="Телеграм" />
<img  style={{paddingLeft:"22px"}} src="/images/logoTiktok.png"  alt="Тікток" />
<img  style={{paddingLeft:"22px"}} src="/images/logoInstagram.png"  alt="Інстаграм" />
<img  style={{paddingLeft:"22px"}} src="/images/logoFacebook.png"  alt="Фейсбук" />
</div>
      <img src="/images/FooterRuslan.png" alt="" />
    </div>
  );
};

export default Footer;