import React from 'react';
import styles from './DirectionComponent.module.css';
const  DirectionComponent = () => {
  return (
    <div style={{marginTop:"97px"}}>
       <img src="/images/showButton.png" className={styles.photo} alt="Фото з public" 
        />
        <div className={styles.titletext}>Триєдність Успіху: Бізнес, Благодійність, Духовність</div>
        <div>
        <div className={styles.logoGrid}>
        <img src="/images/logoDirections/1.png" className={styles.logo} alt="" />
        <img src="/images/logoDirections/2.png" className={styles.logo} alt="" />
        <img src="/images/logoDirections/3.png" className={styles.logo} alt="" />
        <img src="/images/logoDirections/4.png" className={styles.logo} alt="" />
        <img src="/images/logoDirections/5.png" className={styles.logo} alt="" />
        <img src="/images/logoDirections/6.png" className={styles.logo} alt="" />
        <img src="/images/logoDirections/7.png" className={styles.logo} alt="" />
        <img src="/images/logoDirections/8.png" className={styles.logo} alt="" />
        <img src="/images/logoDirections/9.png" className={styles.logo} alt="" />
      </div>
        </div>
    </div>
  );
};

export default DirectionComponent;